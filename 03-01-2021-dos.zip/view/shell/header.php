
<header id="header">
    <h1>
        <a href="http://localhost/Proyecto-Carlos/"> 
        <img ><!--src="http://localhost/Proyecto-Carlos/img/imagenes/isologo.png"-->
        </a>
    </h1>

    <nav> 
        <!--<a href="http://localhost/Proyecto-Carlos/index.php"> Index </a>-->
        <a href="http://localhost/Proyecto-Carlos/view/pages/nosotros.php" class="boton"> Nosotros </a>
        <a href="http://localhost/Proyecto-Carlos/view\pages\servicios.php" class="boton"> Servicios </a>
        <a href="http://localhost/Proyecto-Carlos/view\pages\nuestrosClientes.php" class="boton"> Clientes </a>
        <a href="http://localhost/Proyecto-Carlos/view/pages/contacto.php" class="boton"> Contacto </a>

    </nav>
</header>
