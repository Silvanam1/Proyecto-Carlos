<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="http://localhost/Proyecto-Carlos/general.css">
    <title>Document</title>
</head>
<body>
    <?php
    require('view/shell/header.php');
    ?>
    <a href="view/pages/nosotros.php">ir a la web</a>
    <h2 > Nosotros (breve introducción sobre nosotros) </h2>
    <!--Botón de Nosotros -->
    <h2 > Servicios (breve introducción sobre Servicios) </h2>
    <!--Botón de contacto -->
    <h2>Nuestros Clientes ( logos con los clientes) </h2>
    <h1> Cartelera de clientes</h1>
    <img src="buenosaires.png" alt="Buenos Aires">
    <img src="aerolineasargentinas.png" alt="Aerolineas Argentinas">
    <img src="amia.png" alt="Amia">
    <img src="rex.png" alt="Rex">
    <img src="dufour.png" alt="Dufour">
    <img src="jazminchebar.png" alt="Jazmin Chebar">
    <img src="universidadsanandres.png" alt="Universidad de San Andres">
    <img src="blaque.png" alt="Blaque">
    <img src="samsung.png" alt="Samsung">
    <img src="kansas.png" alt="Kansas">
    <img src="cocot.png" alt="Cocot">
    <img src="burguerking.png" alt="Burguer King">
    <img src="tango.png" alt="Tango">
    <img src="bonafide.png" alt="Bonafide">
    <img src="bago.png" alt="Bagó">
    <img src="lacabrera.png" alt="La Cabrera">
<br>


    <?php
    require('view/shell/footer.php');
    ?>
</body>
</html>