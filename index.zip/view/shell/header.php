
<header id="header">
    <h1><a href="http://localhost/Proyecto-Carlos/index.php"> DIMVER </a></h1>
    <nav> 
        <!--<a href="http://localhost/Proyecto-Carlos/index.php"> Index </a>-->
        <a href="http://localhost/Proyecto-Carlos/index.php"> Nosotros </a>
        <a href="http://localhost/Proyecto-Carlos/index.php"> Servicios </a>
        <a href="http://localhost/Proyecto-Carlos/index.php"> Cartelera </a>
        <a href="http://localhost/Proyecto-Carlos/index.php"> Contacto </a>

    </nav>
</header>
