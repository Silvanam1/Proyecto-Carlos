<hr>
<footer id="footer">
    <section>
        <article>
            <h3>Contactenos</h3>
            <ul>
                <li>
                    <a href="https://www.google.com.ar/maps/place/Gral.+Manuel+Blanco+Encalada+1983,+B1712CFE+Castelar,+Provincia+de+Buenos+Aires/@-34.6517544,-58.6359088,17z/data=!3m1!4b1!4m5!3m4!1s0x95bcc7582fa36289:0x42a45bc834b24483!8m2!3d-34.6517588!4d-58.6337201" class="btn rojo">
                        <i class="fa fa-map"></i>
                    </a>
                    BLANCO ENCALADA 1983, CASTELAR
                </li>
                <li>
                    Telefonos Moviles
                </li>
                <li>
                    <ul>
                        <li>
                        <a href="https://api.whatsapp.com/send?phone=5491533326375" class="btn verde">
                        <i class="fab fa-whatsapp"></i></a> 1533326375
                        
                        </li>
                        <li>
                        <a href="https://api.whatsapp.com/send?phone=5491533326375" class="btn verde">
                        <i class="fab fa-whatsapp"></i></a> 1533326375
                        
                        </li>                       
                    </ul>
                </li>
                <li>
                    Telefonos Fijos
                </li>
                <li>
                    <ul>
                        <li>
                            <i class="fa fa-phone" aria-hidden="true"></i> 
                            4628-6907 / 4629-5298
                        </li>                     
                    </ul>
                </li>
            </ul>
        </article>
        <article>
            <img src="qr.jpg" alt="">
        </article>
    </section>
</footer>