<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../general.css">
    <title>Document</title>
</head>
<body>
    <?php
    require('../shell/header.php');
    ?>
    <a href="../../index.php">ir al index</a>
    <br>
    <h1> Nuestros Clientes</h1>
    <img src="../../buenosaires.png" alt="Buenos Aires">
    <img src="../../aerolineasargentinas.png" alt="Aerolineas Argentinas">
    <img src="../../amia.png" alt="Amia">
    <img src="../../rex.png" alt="Rex">
    <img src="../../dufour.png" alt="Dufour">
    <img src="../../jazminchebar.png" alt="Jazmin Chebar">
    <img src="../../universidadsanandres.png" alt="Universidad de San Andres">
    <img src="../../blaque.png" alt="Blaque">
    <img src="../../samsung.png" alt="Samsung">
    <img src="../../kansas.png" alt="Kansas">
    <img src="../../cocot.png" alt="Cocot">
    <img src="../../burguerking.png" alt="Burguer King">
    <img src="../../tango.png" alt="Tango">
    <img src="../../bonafide.png" alt="Bonafide">
    <img src="../../bago.png" alt="Bagó">
    <img src="../../lacabrera.png" alt="La Cabrera">
<br>
<p>Nota: Se omiten citar, del listado de alrededor de 15.000 Abonados, que se encuentra instalado el sistema de monitoreo, en viviendas particulares, el fin de seguir la política de la empresa, para preservar su privacidad. </p>
<br>
<h2>AMBAS EMPRESAS SE ENCUENTRAN ASOCIADAS AL:</h2>
<img src="../../forodeseguridad.png" alt="Foro de Seguridad">
<script src="https://kit.fontawesome.com/f3c3af2199.js" crossorigin="anonymous"></script>
    <?php
    require('../shell/footer.php');
    ?>
</body>
</html>