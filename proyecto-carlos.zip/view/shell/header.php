<header id="header">
    <h1>
        <a href="http://dimver.com.ar/"> 
        <img ><!--src="http://localhost/Proyecto-Carlos/img/imagenes/isologo.png"-->
        </a>
    </h1>

    <nav> 
        <!--<a href="http://localhost/Proyecto-Carlos/index.php"> Index </a>-->
        <a href="http://dimver.com.ar/view/pages/nosotros.php" class="boton"> Nosotros </a>
        <a href="http://dimver.com.ar/view\pages\servicios.php" class="boton"> Servicios </a>
        <a href="http://dimver.com.ar/view\pages\nuestrosClientes.php" class="boton"> Clientes </a>
        <a href="http://dimver.com.ar/view/pages/contacto.php" class="boton"> Contacto </a>

    </nav>
</header>