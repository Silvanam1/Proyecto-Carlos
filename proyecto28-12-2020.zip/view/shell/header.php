
<header id="header">
    <h1><a href=""> <img src="img\imagenes\logo3solo.png" alt="Logo Dimver, hipervinculo a Index"> </a></h1>
    <nav> 
        <!--<a href="http://localhost/Proyecto-Carlos/index.php"> Index </a>-->
        <a href="" class="boton"> Nosotros </a>
        <a href="" class="boton"> Servicios </a>
        <a href="" class="boton"> Cartelera </a>
        <a href="" class="boton"> Contacto </a>

    </nav>
</header>
