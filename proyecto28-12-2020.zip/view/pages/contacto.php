<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacto</title>
</head>
<body>
    <?php
    require('../shell/header.php');
    ?>
    <a href="../../index.php">ir al index</a>

    <h1>Contacto</h1>
    <!--La idea es agregar luego el  Afip “Q.R”-->
    <p>BLANCO ENCALADA 1983, CASTELAR. (CP 1712) </p>
    <p>TELÉFONOS: 4628-6907 / 4629-5298</p>
    <p>CELULAR: 153-332-6375</p>
    <p>ALTERNATIVO: 152-644-2919</p>
    <p>CORREO ELECTRÓNICO: DIMVER2020@GMAIL.COM</p>
    
    <?php
    require('../shell/footer.php');
    ?>
</body>
</html>
