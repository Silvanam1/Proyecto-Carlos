<header id="header">
    <h1>
        <a href="http://dimver.com.ar/"> 
            <picture>
                <source srcset="http://dimver.com.ar/img/imagenes/logo2021.png" media="(max-width: 600px)">
                <source srcset="http://dimver.com.ar/img/imagenes/isologo2021.png" media="(max-width: 1160px)">
                <img src="http://dimver.com.ar/img/imagenes/isologotipo2021.png">
            </picture>
        </a>
    </h1>

    <nav> 
        <a href="http://dimver.com.ar/view/pages/nosotros.php" class="boton"> Nosotros </a>
        <a href="http://dimver.com.ar/view\pages\servicios.php" class="boton"> Servicios </a>
        <a href="http://dimver.com.ar/view\pages\nuestrosClientes.php" class="boton"> Clientes </a>
        <a href="http://dimver.com.ar/view/pages/contacto.php" class="boton"> Contacto </a>
    </nav>
</header>