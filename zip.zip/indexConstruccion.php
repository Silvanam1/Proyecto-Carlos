<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://dimver.com.ar/general.css">
    <!-- http://localhost/Proyecto-Carlos/general.css -->
    <script src="https://kit.fontawesome.com/f3c3af2199.js" crossorigin="anonymous"></script>
    <title>DIMVER</title>

</head>
<body>
    <?php
    require('view/shell/header.php');
    ?>
    <main>
        <h1 class="h1Construccion">Sitio en construccion</h1>
    </main>
    <?php
    require('view/shell/footer.php');
    ?>
</body>
</html>